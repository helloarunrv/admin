<html xmlns='https://www.w3.org/1999/xhtml'>
<head></head>
<body>
    <form action="{{ $redirectUrl }}" method="post" id="form1" name="from1">
    @foreach ($requestParams as $a => $b)
    {{-- {{ dd(htmlentities($b)) }} --}}
        <input type="hidden" name="{{ $a }}" value="{{ $b }}">
    @endforeach
    <script type='text/javascript'>
     document.from1.submit();
    </script>
    </form>
</body>
</html>
