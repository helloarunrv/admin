<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="{{asset('public/assets/modules/payment/css.css')}}">
    <title>Iyzipay Payment</title>

    <style>
        .container-body {
            min-height: 100vh;
            display: flex;
            flex-wrap: wrap;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }
        .form-control {
            background-color: #fff;
            color: #000;
            block-size: 45px;
            font-size: 1rem;
        }

        .form-control:focus {}
    </style>

</head>
<body>
    <div class="container container-body">
        <div class="w-100">
            <div class="row justify-content-center">
                <div class="col-lg-6 col-md-7 col-xl-5">
                    <div class="card">
                        <div class="card-body">
                            <form action="{{route('iyzipay.payment', ['payment_id' => $payment_id])}}" method="get">
                                <input type="hidden" name="payment_id" class="form-control" value="{{$payment_id}}">
                                <div class="row g-3">
                                    <div class="col-md-12">
                                            <label class="input-label" for="exampleFormControlInput1">zipcode</label>
                                            <input type="number" name="zip" class="form-control" placeholder="zipcode" required>
                                    </div>
                                    <div class="col-md-12">
                                        <label class="input-label" for="exampleFormControlInput1">city</label>
                                        <input type="text" name="city" class="form-control" placeholder="city" required>
                                    </div>
                                    <div class="col-12">
                                        <div class="d-flex gap-3 justify-content-end">
                                            <button type="reset" id="reset_btn" class="btn btn--reset">Reset</button>
                                            <button type="submit" class="btn btn-primary">Next</button>
                                        </div>
                                    </div>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
