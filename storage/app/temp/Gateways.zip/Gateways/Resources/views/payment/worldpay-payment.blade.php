<!DOCTYPE html>
<html lang="en">

<head>
  <title>Worldpay PAYMENT</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&amp;display=swap" rel="stylesheet">
    {{-- <link rel="stylesheet" href="{{asset('public/assets/admin')}}/css/theme.minc619.css?v=1.0"> --}}
  <link rel="stylesheet" href="{{asset('public/assets/modules/payment/toastr.css')}}">
  {{-- <script src="{{asset('assets/payment/js')}}/vendor.min.js"></script>
  <script src="{{asset('assets/payment')}}/js/theme.min.js"></script> --}}
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="{{asset('public/assets/modules/payment/js/toastr.js')}}"></script>

  <style>
    .container-fluid {
      background-color: #C5CAE9
    }

    .heading {
      font-size: 40px;
      margin-top: 35px;
      margin-bottom: 30px;
      padding-left: 20px
    }

    .card {
      border-radius: 10px !important;
      margin-top: 60px;
      margin-bottom: 60px
    }

    .form-card {
      margin-left: 20px;
      margin-right: 20px
    }

    .form-card input,
    .form-card textarea {
      padding: 10px 15px 5px 15px;
      border: none;
      border: 1px solid lightgrey;
      border-radius: 6px;
      margin-bottom: 25px;
      margin-top: 2px;
      width: 100%;
      box-sizing: border-box;
      font-family: arial;
      color: #2C3E50;
      font-size: 14px;
      letter-spacing: 1px
    }

    .form-card input:focus,
    .form-card textarea:focus {
      -moz-box-shadow: 0px 0px 0px 1.5px skyblue !important;
      -webkit-box-shadow: 0px 0px 0px 1.5px skyblue !important;
      box-shadow: 0px 0px 0px 1.5px skyblue !important;
      font-weight: bold;
      border: 1px solid #304FFE;
      outline-width: 0
    }

    .input-group {
      position: relative;
      width: 100%;
      overflow: hidden
    }

    .input-group input {
      position: relative;
      height: 80px;
      margin-left: 1px;
      margin-right: 1px;
      border-radius: 6px;
      padding-top: 30px;
      padding-left: 25px
    }

    .input-group label {
      position: absolute;
      height: 24px;
      background: none;
      border-radius: 6px;
      line-height: 48px;
      font-size: 15px;
      color: gray;
      width: 100%;
      font-weight: 100;
      padding-left: 25px
    }

    input:focus+label {
      color: #304FFE
    }

    .btn-pay {
      background-color: #304FFE;
      height: 60px;
      color: #ffffff !important;
      font-weight: bold
    }

    .btn-pay:hover {
      background-color: #3F51B5
    }
  </style>
</head>

<body>
  <div class="container-fluid">
    <div class="row justify-content-center">
      <div class=" col-lg-6 col-md-8">
        <div class="card p-3">
          <div class="row justify-content-center">
            <div class="col-12">
              <h2 class="heading text-center">World Pay</h2>
            </div>
          </div>
          <form action="{{route('worldpay.payment',['payment_id'=>$payment_data->id])}}" class="form-card" method="post" id="wp_payment_form">
            @csrf
            <input type="hidden" name="session_id" id="sessionId">
            <div class="row justify-content-center">
              <div class="col-12">
                <div class="input-group"> <input type="text" name="Name" value="{{old('Name')}}" placeholder="John Doe"> <label>Card holder name</label> </div>
              </div>
            </div>
            <div class="row justify-content-center">
              <div class="col-12">
                <div class="input-group"> <input type="text" id="cr_no" name="card_no" value="{{old('card_no')}}" placeholder="0000 0000 0000 0000" minlength="19" maxlength="19"> <label>Card Number</label> </div>
              </div>
            </div>
            <div class="row justify-content-center">
              <div class="col-12">
                <div class="row">
                  <div class="col-6">
                    <div class="input-group"> <input type="text" id="exp" name="expdate" placeholder="MM/YY" minlength="5" maxlength="5" value="{{old('expdate')}}"> <label>Expiry Date</label> </div>
                  </div>
                  <div class="col-6">
                    <div class="input-group"> <input type="password" name="cvv" placeholder="&#9679;&#9679;&#9679;" minlength="3" maxlength="3" value="{{old('cvv')}}"> <label>CVV</label> </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="row justify-content-center">
              <div class="col-md-12"> <input type="submit" value="Pay {{$payment_data->payment_amount}} {{$payment_data->currency_code}}" class="btn btn-pay placeicon"> </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  <iframe height="1" width="1" name="myfram" src="about:blank">
  </iframe>
  {!! Toastr::message() !!}

  @if ($errors->any())
      <script>
          @foreach($errors->all() as $error)
          toastr.error('{{$error}}', Error, {
              CloseButton: true,
              ProgressBar: true
          });
          @endforeach
      </script>
  @endif
  <script>
    var sessionIdStatus = false;
    var cardNumber = 0;
    function hiddenIframe(sanitizedCardValue) {
        let form = document.createElement('form');
        form.method = 'POST';
        form.action = "https://secure-test.worldpay.com/shopper/3ds/ddc.html";
        form.setAttribute('target', 'myfram');
        let fields = [
          {
            name:'Bin',
            value: sanitizedCardValue //4444333322221111
          },
          {
            name:'JWT',
            value: "{{$jwt}}"
          }
        ];

        for (let field in fields) {
          let input = document.createElement('input');
          input.name = fields[field].name;
          input.value = fields[field].value;
          // input.id = fieldName;
          input.setAttribute('type', 'hidden');
          form.appendChild(input);
        }

        document.body.appendChild(form);
        form.submit();
    }
    $(document).ready(function () {

    $('#wp_payment_form').on('submit', function(e){
      var card = document.getElementById('cr_no');
      var sanitizedCardValue = card.value.replace(/[^0-9]/gi, '');
      console.log('Sanitize___', sanitizedCardValue, sessionIdStatus);
      if(sanitizedCardValue != cardNumber){
        sessionIdStatus = false;
        cardNumber = sanitizedCardValue;
      }
      if(sanitizedCardValue.length < 6){
        toastr.error('Please enter a valid card number', Error, {
              CloseButton: true,
              ProgressBar: true
          });
          return false;
      }
      if(sessionIdStatus){
        console.log('Submit__');
        return true;
      }else{
        console.log('Prevent submit__');
        e.preventDefault();
        hiddenIframe(sanitizedCardValue);
        return false;
      }
      console.log('Nothing submit__');
    })
    });
    $(document).ready(function() {
       //For Card Number formatted input
      var cardNum = document.getElementById('cr_no');
      cardNum.onkeyup = function(e) {
        if (this.value == this.lastValue) return;
        var caretPosition = this.selectionStart;
        var sanitizedValue = this.value.replace(/[^0-9]/gi, '');
        var parts = [];

        for (var i = 0, len = sanitizedValue.length; i < len; i += 4) {
          parts.push(sanitizedValue.substring(i, i + 4));
        }

        for (var i = caretPosition - 1; i >= 0; i--) {
          var c = this.value[i];
          if (c < '0' || c > '9') {
            caretPosition--;
          }
        }
        caretPosition += Math.floor(caretPosition / 4);

        this.value = this.lastValue = parts.join('-');
        this.selectionStart = this.selectionEnd = caretPosition;
      }

      //For Date formatted input
      var expDate = document.getElementById('exp');
      expDate.onkeyup = function(e) {
        if (this.value == this.lastValue) return;
        var caretPosition = this.selectionStart;
        var sanitizedValue = this.value.replace(/[^0-9]/gi, '');
        var parts = [];

        for (var i = 0, len = sanitizedValue.length; i < len; i += 2) {
          parts.push(sanitizedValue.substring(i, i + 2));
        }

        for (var i = caretPosition - 1; i >= 0; i--) {
          var c = this.value[i];
          if (c < '0' || c > '9') {
            caretPosition--;
          }
        }
        caretPosition += Math.floor(caretPosition / 2);

        this.value = this.lastValue = parts.join('/');
        this.selectionStart = this.selectionEnd = caretPosition;
      };

      window.addEventListener("message", function(event) {
        //This is a Cardinal Commerce URL in live.
        // if (event.origin === "https://secure-test.worldpay.com/*") {
            var data = JSON.parse(event.data);
            if (data !== undefined && data.Status) {
              document.getElementById('sessionId').value = data.SessionId;
              sessionIdStatus = true;
              console.log('sessionCreated',document.getElementById('sessionId').value, data.SessionId);
              $('#wp_payment_form').submit();
            }
        // }
      }, false);
    })
  </script>
</body>


</html>
