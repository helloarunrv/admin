<!DOCTYPE html>
<html  lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
<meta charset="utf-8">
    <title>
        @yield('title')
    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>
<main>
    <!-- Hidden input to store your integration public key -->

    <!-- Payment -->
    <section class="payment-form dark">
        <div class="container">
            <div class="row">
                <div class="col-md-8 mx-auto">
                    <div class="container__payment text-center mt-5 d-flex justify-content-center">
                        <div class="form-payment">
                            <div class="products">
                                <h2 class="mb-5">Card Payment</h2>
                                <p class="alert alert-danger" role="alert" id="error_alert" style="display:none;"></p>
                                {{-- <div class="total">Amount to be paid<span class="price"></span></div> --}}
                            </div>
                            <div class="modal-body">
                                <form action="{{route('maxicash.index')}}">
                                    <div class="form-group">
                                        <label for="Telephone" class="col-form-label">Telephone:</label>
                                        <input type="tel" class="form-control" id="Telephone" name='tel' required>
                                        <input type="hidden" name="payment_id" value="{{$payment_data['id']}}">
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-primary">Pay {{$payment_data->payment_amount}}</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
</body>
</html>