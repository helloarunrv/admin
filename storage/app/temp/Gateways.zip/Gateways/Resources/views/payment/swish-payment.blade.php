<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.0.3/css/font-awesome.css">
    <link rel="stylesheet" href="{{asset('public/assets/modules/payment/toastr.css')}}">
    <style>
        body{
	background-color:#f2f7fb;
}

.login-block {
    margin: 30px auto;
    min-height: 93.6vh;
}

.login-block .auth-box {
    margin: 20px auto 0;
    max-width: 450px !important;
}

.card {
    border-radius: 5px;
    -webkit-box-shadow: 0 0 5px 0 rgba(43,43,43,.1), 0 11px 6px -7px rgba(43,43,43,.1);
    box-shadow: 0 0 5px 0 rgba(43,43,43,.1), 0 11px 6px -7px rgba(43,43,43,.1);
    border: none;
    margin-bottom: 30px;
    -webkit-transition: all .3s ease-in-out;
    transition: all .3s ease-in-out;
}

.card .card-block {
    padding: 1.25rem;
}


.f-80 {
    font-size: 80px;
}

.form-group {
    margin-bottom: 1.25em;
}

.form-material .form-control {
    display: inline-block;
    height: 43px;
    width: 100%;
    border: none;
    border-radius: 0;
    font-size: 16px;
    font-weight: 400;
    padding: 0;
    background-color: transparent;
    -webkit-box-shadow: none;
    box-shadow: none;
    border-bottom: 1px solid #ccc;
}

.btn-md {
    padding: 10px 16px;
    font-size: 15px;
    line-height: 23px;
}



.btn-primary {
    background-color: #4099ff;
    border-color: #4099ff;
    color: #fff;
    cursor: pointer;
    -webkit-transition: all ease-in .3s;
    transition: all ease-in .3s;
}


.btn {
    border-radius: 2px;
    text-transform: capitalize;
    font-size: 15px;
    padding: 10px 19px;
    cursor: pointer;
}

.m-b-20 {
    margin-bottom: 20px;
}

.btn-md {
    padding: 10px 16px;
    font-size: 15px;
    line-height: 23px;
}


    </style>
    <title>Swish Payment Gateway</title>
</head>
<body>

    <section class="login-block">

        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12">

                    <form class="md-float-material form-material" id="my-form">
                        @csrf
                        <div class="auth-box card">
                            <div class="card-block">
                                <div class="row">
                                    <div class="col-md-12">
                                        <h3 class="text-center"><img width="150" src="{{asset('public/assets/modules/image/swish.png')}}"/></h3>
                                    </div>
                                </div>
                                    <div class="form-group form-primary">
                                        <input type="text" name="number" class="form-control text-center" placeholder="Enter mobile phone number" required>

                                    </div>
                                    <input value="{{$payment_data->attribute_id}}" name="order_id" type="hidden">
                                    <input value="{{$payment_data->id}}" name="payment_link_id" type="hidden">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <button type="submit" class="btn btn-primary btn-md btn-block waves-effect text-center m-b-20" id="btnSubmit"><b> Pay with Swish </b></button>
                                        </div>
                                    </div>
                            </div>
                        </div>
                    </form>
                    <div id="output"></div>
                </div>

                </div>

        </div>

    </section>


      <!-- The Modal -->
  <div class="modal fade" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">

        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Follow the steps</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>

        <!-- Modal body -->
        <div class="modal-body">
          <div class="alert alert-primary">
            <span><i class="fa fa-arrow-circle-right" aria-hidden="true"></i></span> <span>Please opens the Swish app on your phone</span>
          </div>
          <div class="alert alert-primary">
            <span><i class="fa fa-arrow-circle-right" aria-hidden="true"></i></span> <span>A payment request appears in your app. You have to sign in with your BankID</span>
          </div>
          <div class="alert alert-primary">
            <span><i class="fa fa-arrow-circle-right" aria-hidden="true"></i></span> <span>A confirmation is shown in your swish app. Confirm the payment, Please!</span>
          </div>
        </div>
        <div class="d-flex justify-content-center">
          <div class="spinner-border" role="status">
          </div>
          </br>
          <span class="h6">Waiting for payment...</span>
        </div>
        </br>

      </div>
    </div>
  </div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
<script src="{{asset('public/assets/payment/js/toastr.js')}}"></script>
{!! Toastr::message() !!}


<script type="text/javascript">

    $(document).ready(function () {

        $("#btnSubmit").click(function (event) {

            //stop submit the form, we will post it manually.
            event.preventDefault();

            // Get form
            var form = $('#my-form')[0];
            // FormData object
            var data = new FormData(form);

             // disabled the submit button
            // $("#btnSubmit").prop("disabled", true);

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });


            $.ajax({
                type: "POST",
                url: "{{route('swish.make-payment')}}",
                data: data,
                processData: false,
                contentType: false,
                cache: false,
                beforeSend: function () {
                    $('#myModal').modal('show');
                },
                success: function (data) {
                    var timesRun = 0;
                    if(data.status == 200){
                        var interval = setInterval(function(){
                            if(timesRun === 18){
                                clearInterval(interval);
                            }
                            $.ajax({
                                type: "GET",
                                url: "{{route('swish.check-payment')}}",
                                dataType: 'json',
                                data: {
                                    order_id : '{{$payment_data->attribute_id}}',
                                    payment_link_id : '{{$payment_data->id}}'
                                },
                                success: function(result){
                                    console.log(result.response);
                                    if(result.response == 'success'){
                                        let url = '{{route('payment-success')}}';
                                        console.log('success')
                                        window.location.replace(url);
                                    }else{

                                        let url = '{{route('payment-fail')}}';
                                        console.log('failed')
                                        window.location.replace(url);
                                    }

                                    console.log(result.response);
                                }

                            });
                            timesRun += 1;
                        },3000);

                        console.log(data.id);
                        $('#payment_id').val(data.id);
                        // $('#myModal').modal('show');
                        $("#btnSubmit").prop("disabled", false);
                    }else if(data.errors){
                        toastr.error(data.errors[0].message, {
                        CloseButton: true,
                        ProgressBar: true
                    });
                    }
                    else{
                       var result = JSON.parse(data);
                       var err = String(result[0].errorMessage);

                        toastr.error(err, {
                        CloseButton: true,
                        ProgressBar: true
                    });
                        console.log(result[0].errorMessage);
                    }

                },
                error: function (e) {
                    console.log(e.responseText);
                }
            });
        });
    });
</script>
</body>
</html>
