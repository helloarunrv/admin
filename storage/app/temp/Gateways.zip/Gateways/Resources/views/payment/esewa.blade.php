<!DOCTYPE html>
<html  lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
<meta charset="utf-8">
    <title>
        @yield('title')
    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>
<main>
    <!-- Hidden input to store your integration public key -->

    <!-- Payment -->
    <section class="payment-form dark">
        <div class="container mt-5">
            <div class="row">
                <div class="col-md-6 mb-4" style="cursor: pointer">
                    <div class="card">
                        <div class="card-body" style="height: 100px">
                            <form action="{{$config_mode == 'test' ? 'https://uat.esewa.com.np/epay/main':'https://merchant.esewa.com.np'}}" method="POST">
                                <input value="{{$data->payment_amount}}" name="tAmt" type="hidden">
                                <input value="{{$data->payment_amount}}" name="amt" type="hidden">
                                <input value="0" name="txAmt" type="hidden">
                                <input value="0" name="psc" type="hidden">
                                <input value="0" name="pdc" type="hidden">
                                <input value="EPAYTEST" name="scd" type="hidden">
                                <input value="{{$data->id}}" name="pid" type="hidden">
                                <input value="{{ route('esewa.verify', ['payment_id' => $data->id]) }}?q=su" type="hidden" name="su">
                                <input value="{{ route('esewa.verify', ['payment_id' => $data->id]) }}?q=fu" type="hidden" name="fu">
                                <button class="btn btn-block click-if-alone" type="submit">
                                    <img width="150" src="{{asset('public/assets/modules/image/esewa.png')}}"/>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
</body>
</html>
