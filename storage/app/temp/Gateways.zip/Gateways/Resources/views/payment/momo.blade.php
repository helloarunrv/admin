<!DOCTYPE html>
<html lang="en">
<head>
  <title>MTN MOMO PAYMENT</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
	<div class="container py-3">
        <div class="row">
          <div class="col-md-12">

            <div class="row justify-content-center">
                <div class="col-md-6">
                              <!-- form card payment -->
                  <div class="card card-outline-secondary">
                    <div class="card-header">
                      <h3 class="mb-0 text-center"><img style="max-width: 100px; margin-top: -5px"
                        src="{{asset('public/assets/modules/image/momo.png')}}"/></h3>
                    </div>
                    <div class="card-body">
                        <form action="{{route('momo.callback')}}">
                            <input type="hidden" name="orderID" value="{{$data->attribute_id}}">
                            <input type="hidden" name="paymentID" value="{{$data->id}}">
                            <div class="form-group">
                                <label for="mobile_number">Amount</label>
                                    <input class="form-control" value="{{$data->payment_amount}}" name="order_amount" type="text" readonly style="border: none">
                            </div>
                            <div class="form-group">
                                <label for="mobile_number">Phone Number</label>
                                    <input class="form-control" id="mobile_number" name="mobile_number" required="" type="text">
                            </div>
                              <button class="btn btn-success btn-block" type="submit">Procced to payment</button>
                        </form>
                    </div><!--/card-block-->
                  </div><!-- /form card payment -->
                </div>
              </div>

          </div>
        </div>
    </div>



</body>


</html>
