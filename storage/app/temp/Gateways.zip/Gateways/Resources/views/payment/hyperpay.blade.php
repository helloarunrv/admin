<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Hyperpay</title>
    <style>
        body {
            background-color: #f6f6f5;
        }
    </style>
</head>

<body>
    <form action="{{ route('hyperpay.callback', ['payment_id' => $payment_id]) }}" class="paymentWidgets"
        data-brands="VISA MASTER">
    </form>
    @if ($config_mode == 'test')
        <script async src="https://eu-test.oppwa.com/v1/paymentWidgets.js?checkoutId={{ $checkoutId }}"></script>
    @else
        <script async src="https://eu-prod.oppwa.com/v1/paymentWidgets.js?checkoutId={{ $checkoutId }}"></script>
    @endif

    <script type="text/javascript">
        var wpwlOptions = {
            style: "card",
            locale: "en",
            paymentTarget:"_top"
        }
    </script>
</body>

</html>
