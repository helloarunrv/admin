<?php return array (
  'software_id' => '0001',
  'name' => 'Payment & Sms gateways',
  'is_published' => 0,
  'database_migrated' => 0,
  'purchase_code' => '',
  'username' => '',
);
