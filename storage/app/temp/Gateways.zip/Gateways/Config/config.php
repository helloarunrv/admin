<?php

return [
    'name' => 'Gateways'
];
